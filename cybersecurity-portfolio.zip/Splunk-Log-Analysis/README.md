# Splunk Log Analysis

## Objective

## Tools & Methodology

## Findings

## Analysis

## Recommendations

## Screenshots
